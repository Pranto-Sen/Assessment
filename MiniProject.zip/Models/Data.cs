﻿namespace Assessment.Models
{
	public class Data
	{
        public string ?date { get; set; }
		public string ?trade_code { get; set; }
		public string ?high { get; set; }
		public string ?low { get; set; }
		public string ?open { get; set; }
		public string ?close { get; set; }
		public string ?volume { get; set; }

	}
}
